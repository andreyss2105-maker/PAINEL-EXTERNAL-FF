# FF Panel Pro para Android

Este projeto transforma o painel HTML enviado em um app Android com WebView e adiciona:
- serviço em primeiro plano com notificação persistente, iniciado pelo usuário;
- botão para solicitar permissão de sobreposição;
- bolha flutuante arrastável que mostra a taxa de atualização reportada pelo Android para a tela.

## Como gerar o APK
1. Abra a pasta `FFPanelAndroid` no Android Studio (versão recente).
2. Aguarde a sincronização do Gradle e a instalação dos componentes Android SDK 35.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Como usar
1. Instale o APK no seu Android.
2. Abra **FF Panel Pro**.
3. Toque em **Ativar segundo plano** para iniciar o serviço e manter a notificação visível.
4. Toque em **Bolha flutuante** e autorize “Exibir sobre outros apps” nas configurações do Android.
5. Volte ao app. A bolha poderá ser arrastada sobre outros aplicativos. Para encerrar, use **Parar** na notificação.

## Limitações importantes
- A bolha mostra a taxa de atualização da tela informada pelo Android; não é uma medição do FPS do Free Fire.
- Android não oferece a apps comuns uma API pública universal para ler o FPS ou o ping interno do Free Fire.
- O app não força 90/120 Hz, não altera configurações internas do jogo e não promete remover lag. A taxa efetiva depende do aparelho, do sistema, do jogo, da temperatura e das opções do fabricante.
- O serviço usa o tipo `specialUse` de foreground service. O Android pode mostrar avisos/permissões e fabricantes podem limitar serviços; o usuário pode parar o serviço a qualquer momento.
- Para publicar na Play Store, será necessário revisar as políticas vigentes de foreground services, sobreposição e declaração do caso de uso. Este projeto foi pensado para instalação de teste/uso próprio.

## Requisitos
- Android Studio
- Android SDK 35
- JDK 17 ou superior


## Compilação automática (sem instalar Android Studio no computador)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. No GitHub, abra a aba **Actions**.
3. Selecione **Build Android APK** e clique em **Run workflow** (ou faça push na branch `main`).
4. Quando terminar, abra a execução concluída e baixe o artefato **FF-Panel-Pro-APK**.
5. Extraia o ZIP do artefato: dentro estará `app-debug.apk`.

O workflow usa JDK 17, Gradle 8.9 e Android SDK 35 para compilar o APK de depuração.
