package com.ffpanel.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.roundToInt

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var windowManager: WindowManager? = null

    companion object {
        const val ACTION_START = "com.ffpanel.pro.START"
        const val ACTION_SHOW_OVERLAY = "com.ffpanel.pro.SHOW_OVERLAY"
        const val ACTION_STOP = "com.ffpanel.pro.STOP"
        private const val CHANNEL_ID = "ff_panel_monitor"
        private const val NOTIFICATION_ID = 41
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                removeBubble()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW_OVERLAY -> showBubble()
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification())
            }
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "FF Panel em segundo plano",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Notificação persistente do monitor do FF Panel" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, MonitorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("FF Panel Pro ativo")
            .setContentText("Indicador em segundo plano. Toque para abrir o painel.")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stopIntent)
        return builder.build()
    }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this) || bubble != null) return
        val view = TextView(this).apply {
            text = "FF PANEL • ATIVO"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xEE17243A.toInt())
            setPadding(18, 14, 18, 14)
            elevation = 12f
            contentDescription = "FF Panel flutuante. Arraste para mover."
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 180
        }

        var initialX = 0
        var initialY = 0
        var downX = 0f
        var downY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    downX = event.rawX; downY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (initialX - (event.rawX - downX)).roundToInt()
                    params.y = (initialY + (event.rawY - downY)).roundToInt()
                    try { windowManager?.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        try {
            windowManager?.addView(view, params)
            bubble = view
            handler.post(updateBubble)
        } catch (_: Exception) {
            bubble = null
        }
    }

    private val updateBubble = object : Runnable {
        override fun run() {
            val view = bubble ?: return
            val hz = try {
                @Suppress("DEPRECATION")
                (windowManager?.defaultDisplay?.refreshRate ?: 0f).roundToInt()
            } catch (_: Exception) { 0 }
            view.text = if (hz > 0) "FF PANEL • ATIVO\nTela: ${hz} Hz" else "FF PANEL • ATIVO"
            handler.postDelayed(this, 2000)
        }
    }

    private fun removeBubble() {
        handler.removeCallbacks(updateBubble)
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    override fun onDestroy() {
        removeBubble()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
